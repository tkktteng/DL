<template>
  <div id="Header">
    <div id="word">
      <h1>{{ msg }}</h1>
    </div>
  </div>
</template>
<script>
export default {
  name: "Header",
  data() {
    return {
      msg: "",
      activeIndex: "1",
    };
  },
  methods: {},
};
</script>
<style scoped>
#Header {
  padding: 30px 110px 0 150px;
  width: 90%;
  margin: 10px auto;
  background: linear-gradient(90deg, rgba(0, 240, 255, 0.1) 0%, rgba(0, 100, 255, 0.05) 100%);
  border-bottom: 1px solid rgba(0, 240, 255, 0.3);
  border-radius: 10px;
}

#word {
  margin-left: 45%;
  margin-top: -35px;
  margin-bottom: 37px;
  height: 60px;
  line-height: 3.2em;
  letter-spacing: 8px;
}

h1 {
  color: #00f0ff;
  letter-spacing: 30px;
  font-size: 2.3em;
  text-shadow: 0 0 20px rgba(0, 240, 255, 0.5);
}

.el-menu-demo {
  width: 80%;
  margin: 0px auto;
  padding: 0px auto;
}

.top-left-edition span i {
  float: left;
  margin-right: 10px;
}

i,
input,
label {
  vertical-align: middle;
}

i {
  border: 0;
  display: block;
  cursor: pointer;
}

.top-left-edition span {
  float: left;
  font-size: 16px;
  color: #00f0ff;
  line-height: 24px;
  margin-right: 40px;
}
</style>


