<template>
  <div id="Footer">
    <p>{{ msg }}</p>
  </div>
</template>
<script>
export default {
  name: "Footer",
  data() {
    return {
      msg: "",
    };
  },
};
</script>
<style scoped>
#Footer {
  padding: 6px;
  border-radius: 5px;
  width: 80%;
  height: 80px;
  margin: 20px auto;
  margin-top: 140px;
  border-top: 1px solid rgba(0, 240, 255, 0.2);
}

p {
  color: #00f0ff;
  text-align: center;
  margin: 30px auto;
  font-size: 1.1em;
  text-shadow: 0 0 10px rgba(0, 240, 255, 0.3);
}
</style>


