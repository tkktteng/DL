<template>
  <div id="app">
    <app-header></app-header>
    <app-content></app-content>
    <app-footer></app-footer>
  </div>
</template>

<script>
import Header from "./components/Header";
import Footer from "./components/Footer";
import Content from "./components/Content";
export default {
  name: "眼疾辅助诊断系统",
  data() {
    return {};
  },
  components: {
    "app-header": Header,
    "app-footer": Footer,
    "app-content": Content,
  },
  methods: {},
};
</script>

<style>
#app {
  min-height: 100vh;
  background: linear-gradient(135deg, #0a0f1a 0%, #1a1f3a 50%, #0d1421 100%);
}
</style>
